package es.urjc.mov.lbajo.miner;

import org.junit.Test;

import static junit.framework.Assert.*;

public class MinerTest {

    private Miner miner = new Miner();

    private void init() {
        int id = 0;
        miner.map = new int[miner.cells];
        miner.coordinates = new int[miner.rows][miner.columns];

        for (int i = 0; i < miner.rows; i++) {
            if (i == 5 || i == 7) {
                miner.map[i] = 1;
            } else {
                miner.map[i] = 0;
            }
            for (int j = 0; j < miner.columns; j++) {
                miner.coordinates[i][j] = id;
                id++;
            }
        }
    }

    @Test
    public void searchBomb() throws Exception {
        init();
        assertEquals(miner.searchBomb(5), true);
    }

    @Test
    public void getBombId() throws Exception {
        init();
        assertEquals(miner.getBombId(1, 1), 9);
    }

    @Test
    public void getRow() throws Exception {
        init();
        assertEquals(miner.getRow(9), 1);
    }

    @Test
    public void getColumn() throws Exception {
        init();
        assertEquals(miner.getColumn(9), 1);
    }

    @Test
    public void neighbours() throws Exception {
        init();
        assertEquals(miner.neighbours(5), 0);
        assertEquals(miner.neighbours(4), 1);
    }

}