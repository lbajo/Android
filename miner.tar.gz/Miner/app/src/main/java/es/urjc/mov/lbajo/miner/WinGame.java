package es.urjc.mov.lbajo.miner;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class WinGame extends Activity {

    boolean sound_on=false;

    private class oneClick implements View.OnClickListener {
        public void onClick(View v) {
            ImageButton but = (ImageButton) v;
            if (but.getId() == R.id.btn_new) {
                Intent atras = new Intent(WinGame.this, MainActivity.class);
                atras.putExtra("sound_on", sound_on);
                startActivity(atras);
            } else if (but.getId() == R.id.btn_exit) {
                finish();
                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_HOME);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_win);
        ImageButton but_new = (ImageButton) findViewById(R.id.btn_new);
        but_new.setOnClickListener(new oneClick());
        ImageButton but_exit = (ImageButton) findViewById(R.id.btn_exit);
        but_exit.setOnClickListener(new oneClick());
        Intent i = getIntent();
        Bundle msg = i.getExtras();
        if(msg != null){
            Boolean sound_on = msg.getBoolean("sound_on");
            if(sound_on != null){
                this.sound_on=sound_on;
            }
        }
    }
}
