package es.urjc.mov.lbajo.miner;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.widget.ImageButton;

import static java.lang.Thread.currentThread;
import static java.lang.Thread.sleep;

class Sounds {

    private final int duration = 1;
    private final int sampleRate = 6000; //8000;
    private final int numSamples = duration * sampleRate;
    private final double sample[] = new double[numSamples];
    private final byte generatedSound[] = new byte[2 * numSamples];
    public boolean sonando = false;


    synchronized void playButton(final ImageButton but, final int nei) {

        final Thread thread = new Thread(new Runnable() {
            public void run() {
                double freq = newFreq(nei);
                newSound(freq);
                but.post(new Runnable() {
                    public void run() {
                        sonando = true;
                        try {
                            for (int i = 0; i < nei; ++i) {
                                playSound();
                                try {
                                    sleep(700);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                            }
                            sonando = false;

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                });
            }
        });
        thread.start();

    }

     void killTh() {
        if (sonando)
            currentThread().interrupt();
    }

    private void newSound(double freq) {
        for (int i = 0; i < numSamples; ++i) {
            sample[i] = Math.sin(2 * Math.PI * i / (sampleRate / freq));
        }
        // convert to 16 bit pcm sound array
        // assumes the sample buffer is normalised.
        int idx = 0;
        for (final double dVal : sample) {
            // scale to maximum amplitude
            final short val = (short) ((dVal * 32767));
            // in 16 bit wav PCM, first byte is the low order byte
            generatedSound[idx++] = (byte) (val & 0x00ff);
            generatedSound[idx++] = (byte) ((val & 0xff00) >>> 8);

        }
    }

    private void playSound() {
        final AudioTrack audioTrack = new AudioTrack(AudioManager.STREAM_MUSIC,
                sampleRate, AudioFormat.CHANNEL_OUT_STEREO,
                AudioFormat.ENCODING_PCM_16BIT, generatedSound.length,
                AudioTrack.MODE_STATIC);
        audioTrack.write(generatedSound, 0, generatedSound.length);
        audioTrack.play();

    }

    private int newFreq(int nei) {
        int freq;
        switch (nei) {
            case 0:
                freq = 300;
                break;
            case 1:
                freq = 350;
                break;
            case 2:
                freq = 400;
                break;
            case 3:
                freq = 450;
                break;
            case 4:
                freq = 500;
                break;
            case 5:
                freq = 550;
                break;
            case 6:
                freq = 600;
                break;
            case 7:
                freq = 650;
                break;
            case 8:
                freq = 700;
                break;
            default:
                freq = 800;
                break;
        }
        return freq;
    }
}
