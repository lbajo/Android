package es.urjc.mov.lbajo.miner;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Miner miner = new Miner();
    Sounds sound = new Sounds();

    private boolean sound_on =false;

    protected int[] cells_uncovered = new int[miner.cells];
    protected boolean end = false;

    protected class oneClick implements View.OnClickListener {
        public void onClick(View v) {
            int time = Toast.LENGTH_LONG;
            Toast msg_bomb = Toast.makeText(MainActivity.this, "Hay " + Integer.toString(miner.bombs) + " bombas y " +
                    Integer.toString(miner.no_bombs) + " zonas seguras", time);

            if (!end) {
                ImageButton but = (ImageButton) v;
                int n = but.getId();

                if (n == R.id.boton) {
                    msg_bomb.show();
                } else {
                    if (miner.searchBomb(n)) {
                        but.setImageResource(R.mipmap.bomba3);
                        but.setScaleType(ImageView.ScaleType.CENTER);

                        if (sound_on)
                            sound.playButton(but, -1);

                        end = true;
                        Intent lose = new Intent(MainActivity.this, LoseGame.class);
                        lose.putExtra("sound_on", sound_on);
                        startActivity(lose);
                    } else {
                        if (cells_uncovered[n] == 0) {
                            if(sound_on && sound.sonando)
                                sound.killTh();

                            but.setImageResource(R.mipmap.n0 + miner.neighbours(n));
                            but.setScaleType(ImageView.ScaleType.CENTER);

                            if (miner.neighbours(n) == 0) {
                                zero(n);
                            } else {
                                cells_uncovered[n] = 1;
                            }

                            if (sound_on)
                                sound.playButton(but, miner.neighbours(n));

                            if (compare()) {
                                end = true;
                                Intent win = new Intent(MainActivity.this, WinGame.class);
                                win.putExtra("sound_on", sound_on);
                                startActivity(win);
                            }
                        }
                    }
                }
            }
        }
    }

    protected class twoClick implements View.OnLongClickListener {
        public boolean onLongClick(View v) {
            if (end) {
                return true;
            }
            ImageButton but = (ImageButton) v;
            but.setImageResource(R.mipmap.bandera);
            but.setScaleType(ImageView.ScaleType.CENTER);
            return true;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        Intent i = getIntent();
        Bundle msg = i.getExtras();
        if(msg != null){
            Boolean sound_on = msg.getBoolean("sound_on");
            if(sound_on != null){
                this.sound_on=sound_on;
            }
        }
        newBoard();
        System.err.println(sound_on);
        miner.init(13);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.conf, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        String txtHelp = "__________________AYUDA_________________\n" +
                "Haga click sobre las distintas celdas de la tabla, intente evitar las bombas, " +
                "si encuentra una bomba perderá y la partida acabará automáticamente.\n" +
                "¡Mucha suerte!";
        int time = Toast.LENGTH_LONG;
        Toast msg = Toast.makeText(MainActivity.this, txtHelp, time);

        switch (item.getItemId()) {
            case R.id.help:
                msg.show();
                return true;
            case R.id.easy:
                newBoard();
                miner.init(5);
                cells_uncovered = new int[miner.cells];
                end = false;
                return true;
            case R.id.medium:
                newBoard();
                miner.init(15);
                cells_uncovered = new int[miner.cells];
                end = false;
                return true;
            case R.id.hard:
                newBoard();
                miner.init(35);
                cells_uncovered = new int[miner.cells];
                end = false;
                return true;
            case R.id.on:
                sound_on=true;
                return true;
            case R.id.off:
                sound_on=false;
                return true;
            case R.id.exit:
                finish();
                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_HOME);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    protected void newBoard() {
        int ColorBackgr = Color.parseColor("#FAFAFA");
        setContentView(R.layout.activity_main);

        ImageButton but = (ImageButton) findViewById(R.id.boton);
        but.setOnClickListener(new oneClick());
        but.setBackgroundColor(ColorBackgr);

        int num = 0;

        TableLayout board = (TableLayout) findViewById(R.id.tabla);

        for (int i = 0; i < miner.rows; i++) {
            TableRow tableRow = new TableRow(this);
            tableRow.setLayoutParams(new TableLayout.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.MATCH_PARENT,1));
            for (int j = 0; j < miner.columns; j++) {
                ImageButton button = new ImageButton(this);
                button.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.MATCH_PARENT,1));
                button.setImageResource(R.mipmap.inte2);
                button.setScaleType(ImageView.ScaleType.CENTER);
                button.setBackgroundColor(ColorBackgr);

                button.setId(num);
                button.setOnClickListener(new oneClick());
                button.setOnLongClickListener(new twoClick());
                tableRow.addView(button);

                num++;
            }
            board.addView(tableRow);
        }
    }

    protected void zero(int id) {
        int i = miner.getRow(id);
        int j = miner.getColumn(id);

        int imin = i - 1;
        int jmin = j - 1;
        int imax = i + 2;
        int jmax = j + 2;

        for (int a = imin; a < imax; a++) {
            for (int b = jmin; b < jmax; b++) {
                if (a >= 0 && b >= 0 && a < miner.rows && b < miner.columns) {
                    ImageButton button = (ImageButton) findViewById(miner.getBombId(a, b));
                    button.setImageResource(R.mipmap.n0 + miner.neighbours(miner.getBombId(a, b)));
                    button.setScaleType(ImageView.ScaleType.CENTER);
                    if(miner.neighbours(miner.getBombId(a, b))==0 && cells_uncovered[miner.getBombId(a, b)] == 0){
                        cells_uncovered[miner.getBombId(a, b)] = 1;
                   //     System.err.println("idzero2: " + Integer.toString(miner.getBombId(a, b)));
                        zero(miner.getBombId(a, b));
                    }
                    cells_uncovered[miner.getBombId(a, b)] = 1;
                }
            }
        }
    }

    protected boolean compare() {
        int uncovered = 0;
        for (int i = 0; i < miner.cells; i++) {
            if (cells_uncovered[i] == 1 && miner.map[i] == 0)
                uncovered++;
        }
        return uncovered == miner.no_bombs;
    }

}
