package es.urjc.mov.lbajo.miner;

import java.util.Random;

class Miner {

    int rows = 8;
    int columns = 8;
    int cells=rows*columns;
    int bombs=0;
    int no_bombs=0;
    int[] map;
    int[][] coordinates;

    void init(int bombs_max){
        map= new int[cells];
        coordinates = new int[rows][columns];
        Random rnd = new Random();
        int num=0;
        int bombs=0;

        for(int i=0; i < bombs_max; i++){
            int nb=rnd.nextInt(cells);
            if (!searchBomb(nb)){
                map[nb]=1;
                bombs++;
            }else{
                map[nb]=0;
            }
        }

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                coordinates[i][j]=num;
                num++;
            }
        }

        no_bombs=cells-bombs;
        this.bombs=bombs;

    }

    boolean searchBomb(int id) {
        return map[id] == 1;
    }

    int getBombId(int i, int j){
        return  coordinates[i][j];
    }

    int getRow(int id){
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                if(coordinates[i][j]==id){
                    return i;
                }
            }
        }
        return -1;
    }

    int getColumn(int id){
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                if(coordinates[i][j]==id){
                    return j;
                }
            }
        }
        return -1;
    }

    int neighbours(int id){
        int i=getRow(id);
        int j=getColumn(id);

        int nei=0;

        int imin=i-1;
        int jmin=j-1;
        int imax=i+2;
        int jmax=j+2;

        for (int a = imin; a < imax; a++) {
            for (int b = jmin; b < jmax; b++) {
                if(a>=0 && b>=0 && a<rows && b<columns){
                    if(getBombId(a, b)!=id) {
                        nei = nei + map[getBombId(a, b)];
                    }
                }
            }
        }
        return nei;
    }

}


