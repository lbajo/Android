package es.urjc.mov.lbajo.miner;


import android.support.test.rule.ActivityTestRule;

import org.junit.Rule;
import org.junit.Test;

import java.util.Random;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.longClick;
import static android.support.test.espresso.matcher.ViewMatchers.withId;

public class MinerInstrumentedTest {

    @Rule
    public ActivityTestRule<MainActivity> mActivityRule = new ActivityTestRule<>(MainActivity.class);

    @Test
    public void win() {
        for (int i = 0; i < mActivityRule.getActivity().miner.rows; i++) {
            for (int j = 0; j < mActivityRule.getActivity().miner.columns; j++) {
                int id = mActivityRule.getActivity().miner.getBombId(i, j);
                if (!mActivityRule.getActivity().miner.searchBomb(id)) {
                    onView(withId(id)).perform(click());
                }
                if (mActivityRule.getActivity().end) {
                    break;
                }
            }
        }
    }

    @Test
    public void lose() {
        for (int i = 0; i < mActivityRule.getActivity().miner.rows; i++) {
            for (int j = 0; j < mActivityRule.getActivity().miner.columns; j++) {
                int id = mActivityRule.getActivity().miner.getBombId(i, j);
                if (mActivityRule.getActivity().miner.searchBomb(id)) {
                    //     onView(withId(id)).perform(click());
                    onView(withId(id)).perform(longClick());
                }
                if (mActivityRule.getActivity().end) {
                    break;
                }
            }
        }
    }

    @Test
    public void aleatory() {
        Random rnd = new Random();
        while (true) {
            int id = rnd.nextInt(mActivityRule.getActivity().miner.cells);
            onView(withId(id)).perform(click());
            if (mActivityRule.getActivity().cells_uncovered[id] == 0) {
                if (mActivityRule.getActivity().miner.searchBomb(id)) {
                    break;
                }
                if (mActivityRule.getActivity().end) {
                    break;
                }
            }
        }
    }
}
