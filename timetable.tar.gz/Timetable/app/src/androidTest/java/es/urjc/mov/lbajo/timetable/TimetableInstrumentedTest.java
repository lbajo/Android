package es.urjc.mov.lbajo.timetable;

import android.support.test.rule.ActivityTestRule;

import org.junit.Rule;
import org.junit.Test;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.typeText;
import static android.support.test.espresso.matcher.ViewMatchers.withId;

public class TimetableInstrumentedTest {
    @Rule
    public ActivityTestRule<MainActivity> mActivityRule = new ActivityTestRule<>(MainActivity.class);


    @Test
    public void connectionOK(){
        onView(withId(R.id.user)).perform(typeText("Lorena"), closeSoftKeyboard());
        onView(withId(R.id.password)).perform(typeText("android"), closeSoftKeyboard());
        onView(withId(R.id.login)).perform(click());
    }

    @Test
    public void connectionKO(){
        onView(withId(R.id.user)).perform(typeText("desconocido"), closeSoftKeyboard());
        onView(withId(R.id.password)).perform(typeText("desconocido"), closeSoftKeyboard());
        onView(withId(R.id.login)).perform(click());

    }
}
