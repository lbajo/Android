package es.urjc.mov.lbajo.timetable;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;

public class MainActivity extends Activity {

    public EditText user, password;
    private TextView conex;
    ArrayList<String> info = new ArrayList<>();
    Context context = this;
    int num;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = (Button) findViewById(R.id.login);
        user = (EditText) findViewById(R.id.user);
        password = (EditText) findViewById(R.id.password);
        password.setTypeface(Typeface.DEFAULT);
        password.setTransformationMethod(new PasswordTransformationMethod());
        conex = (TextView) findViewById(R.id.txt_conex);
        button.setOnClickListener(buttonConnectOnClickListener);
    }

    OnClickListener buttonConnectOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View arg0) {
            Client client = new Client("10.0.2.2", 8080, context);
            client.execute(user.getText().toString(), password.getText().toString());
        }
    };

    void newDB() {
        DBHelper DB = new DBHelper(getApplicationContext());
        int dL = DB.length;
        for (int i = 0; i < dL; i++) {
            DB.deleteSubject(i);
        }

        dL = DB.length;
        int max = DB.length + num;

        //      for (int i = 0; i < num; i++) { //funciona
    //    System.err.println("db" + DB.length);
        for (int i = dL; i < max; i++) {
            //     System.err.println(info.get(i));
            //   System.err.println("i"+i);
            String[] parts = info.get(i).split("/");
            int len = max;
            if (dL != 0) {
                len = DB.length;
            }

            for (int n = 0; n < len; n++) {
                if (dL != 0) {
                    String subject = DB.getSubject(n).getSubject();
                    if (subject.equals(parts[0])) {
                        DB.updateSubject(i, user.getText().toString(), parts[0], parts[1], parts[2], parts[3]);
                    }

                } else {
                    DB.newSubject(i, user.getText().toString(), parts[0], parts[1], parts[2], parts[3]);
                }
            }
        }
    }

    private class Client extends AsyncTask<String, Void, String> {
        private String address;
        private int port;
        private Context context;
        private ProgressDialog progressDialog;
        String end = "";
        String user;

        Client(String address, int port, Context context) {
            this.address = address;
            this.port = port;
            this.context = context;
        }

        private void readMess(DataInputStream in) throws Exception {
            int j = 0, n = 0;
            String aux = Mess.readMess(in);
            String[] parts = aux.split("/");
            for (String part : parts) {
                if (j == 0 && part.equals("OK")) {
                    end = "OK";
                } else if (j == 0 && part.equals("KO")) {
                    end = "KO";
                    return;
                } else if (j == 1) {
                    n = Integer.parseInt(part);
                    num = n;
                }
                j++;
            }

            for (int i = 0; i < n; i++) {
                String auxx = Mess.readMess(in);
                info.add(i, auxx);
                //    System.err.println(i + " : " + auxx);

            }
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(context);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.setTitle("Connecting to server");
            progressDialog.setMessage("Please wait...");
            progressDialog.show();
        }

        @Override
        protected String doInBackground(String... msgs) {
            DataOutputStream out = null;
            DataInputStream in;
            Socket socket;
            user = msgs[0];

            try {
                //      System.err.println("ad " + address + " port " + Integer.toString(port));
                socket = new Socket(address, port);
                in = new DataInputStream(socket.getInputStream());
                out = new DataOutputStream(socket.getOutputStream());
                Mess.writeMess(out, msgs[0] + "-" + msgs[1] + "-" + DBHelper.VERSION);
                readMess(in);
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (out != null) {
                    try {
                        out.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return end;
        }

        @Override
        protected void onPostExecute(String value) {
            progressDialog.dismiss();

            if (end.equals("OK")) {
                conex.setText("Conexión exitosa");
                newDB();
                Intent calendar = new Intent(MainActivity.this, Calendar.class);
                calendar.putExtra("user", user);
                calendar.putExtra("num", num);
                startActivity(calendar);
            } else {
                conex.setText("Conexión errónea");
            }
        }
    }
}

