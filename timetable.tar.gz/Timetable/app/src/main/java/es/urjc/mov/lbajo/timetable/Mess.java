package es.urjc.mov.lbajo.timetable;


import java.io.DataInputStream;
import java.io.DataOutputStream;

public class Mess {

    protected static void writeMess(DataOutputStream out, String msg) throws Exception {
        byte[] buff = msg.getBytes("UTF-8");
        out.writeInt(buff.length);
        out.write(buff, 0, buff.length);
    }

    protected static String readMess(DataInputStream in) throws Exception {
        int len = in.readInt();
        byte bufin[] = new byte[len];
        in.readFully(bufin);
        return new String(bufin, "UTF-8");
    }
}
