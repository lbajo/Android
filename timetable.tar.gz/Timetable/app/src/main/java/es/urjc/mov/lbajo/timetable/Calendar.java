package es.urjc.mov.lbajo.timetable;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.Toast;

public class Calendar extends Activity {

    protected String user;
    private int numSubjets;
    DBHelper DB;

    protected class oneClick implements View.OnClickListener {
        public void onClick(View v) {
            int time = Toast.LENGTH_LONG;
            Button but = (Button) v;
            int n = but.getId();
            String subject = DB.getSubject(n).getSubject();
            String course = DB.getSubject(n).getCourse();
            String days = DB.getSubject(n).getDays();
            String hours = DB.getSubject(n).getHours();
            Toast msg = Toast.makeText(Calendar.this, subject + "\n" + "Curso: " + course + "\n" + "Días: " + days + "\n" + "Horas: " + hours, time);
            msg.show();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calendar);
        Intent i = getIntent();
        Bundle msg = i.getExtras();
        if (msg != null) {
            user = msg.getString("user");
            numSubjets = msg.getInt("num");

        }
        this.DB = new DBHelper(getApplicationContext());
        createTable();

    }

    protected void createTable() {
        setContentView(R.layout.calendar);
        TableLayout table = (TableLayout) findViewById(R.id.table);
        Subjects s;
        for (int i = 0; i < numSubjets; i++) {
            TableRow tableRow = new TableRow(this);
            tableRow.setLayoutParams(new TableLayout.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.MATCH_PARENT, 1));
            Button cell = new Button(this);
            cell.setId(i);
            String subject = DB.getSubject(i).getSubject();
            cell.setText(subject);
            cell.setOnClickListener(new oneClick());
            tableRow.addView(cell);
            table.addView(tableRow);
        }
    }

}
