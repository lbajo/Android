package es.urjc.mov.lbajo.timetable;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

class DBHelper extends SQLiteOpenHelper {
    private static final String NAME = "app.db";
    public static final int VERSION = 1;
    Context context;
    int length=0;

    private static final String table_timetable = "CREATE TABLE timetable" +
            "(_id INT PRIMARY KEY, name TEXT, subject TEXT, course TEXT, days TEXT, hours TEXT)";

    DBHelper(Context context) {
        super(context, NAME, null, VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(table_timetable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + table_timetable);
        //    Log.v(DBHelper.class.getName(), "Upgrade DB, new version: "+ newVersion  + ", deleting data");
    }

    void newSubject(int id, String name, String subject, String course, String days, String hours) {
        SQLiteDatabase db = getWritableDatabase();
        if (db != null) {
            ContentValues values = new ContentValues();
            values.put("_id", id);
            values.put("name", name);
            values.put("subject", subject);
            values.put("course", course);
            values.put("days", days);
            values.put("hours", hours);

            db.insert("timetable", null, values);
            db.close();
            length++;
        }
    }

    void updateSubject(int id, String name, String subject, String course, String days, String hours) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("_id", id);
        values.put("name", name);
        values.put("subject", subject);
        values.put("course", course);
        values.put("days", days);
        values.put("hours", hours);

        db.update("timetable", values, "_id=" + id, null);
        db.close();
    }

    void deleteSubject(int id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete("timetable", "_id=" + id, null);
        db.close();
        length--;
    }

    Subjects getSubject(int id) {
        SQLiteDatabase db = getReadableDatabase();
        String[] row = {"_id", "name", "subject", "course", "days", "hours"};
        Cursor c = db.query("timetable", row, "_id=" + id, null, null, null, null, null);
        if (c != null) {
            c.moveToFirst();
        }
        Subjects subject = new Subjects(c.getInt(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5));
        db.close();
        c.close();

        return subject;
    }
}