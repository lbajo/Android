package es.urjc.mov.lbajo.timetable;

class Subjects {
    private int id;
    private String name;
    private String subject;
    private String course;
    private String days;
    private String hours;

    Subjects(int id, String name, String subject, String course, String days, String hours) {
        this.id = id;
        this.name = name;
        this.subject = subject;
        this.course = course;
        this.days = days;
        this.hours = hours;
    }

    public int getID() {
        return id;
    }

    public void setID(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getDays() {
        return days;
    }

    public void setDays(String days) {
        this.days = days;
    }

    public String getHours() {
        return hours;
    }

    public void setHours(String hours) {
        this.hours = hours;
    }
}
