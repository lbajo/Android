package es.urjc.mov.lbajo.fichas;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.util.ArrayList;

public class Client extends AsyncTask<String, Void, String> {
    private String address;
    private int port;
    private Context context;
    private ProgressDialog progressDialog;
    String end = "";
    ArrayList<String> info = new ArrayList<>();
    int num;

    Client(String address, int port, Context context) {
        this.address = address;
        this.port = port;
        this.context = context;
    }

    private void readMess(DataInputStream in) throws Exception {
        int j = 0, n = 0;
        String aux = Mess.readMess(in);
        String[] parts = aux.split("/");
        for (String part : parts) {
            if (j == 0 && part.equals("OK")) {
                end = "OK";
            } else if (j == 0 && part.equals("KO")) {
                end = "KO";
                return;
            } else if (j == 1) {
                n = Integer.parseInt(part);
                num = n;
            }
            j++;
        }

        for (int i = 0; i < n; i++) {
            String auxx = Mess.readMess(in);
            info.add(i, auxx);
            // System.err.println(i + " : " + auxx);
        }
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        progressDialog = new ProgressDialog(context);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.setTitle("Connecting to server");
        progressDialog.setMessage("Please wait...");
        progressDialog.show();
    }

    @Override
    protected String doInBackground(String... msgs) {
        DataOutputStream out;
        DataInputStream in;
        Socket socket;

        try {
            socket = new Socket(address, port);
            in = new DataInputStream(socket.getInputStream());
            out = new DataOutputStream(socket.getOutputStream());
            if (msgs[0].equals("first")) {
                Mess.writeMess(out, msgs[1] + "/" + msgs[2] + "/" + msgs[3] + "/" + msgs[4] + "/" + 1);
                readMess(in);
            } else {
                Mess.writeMess(out, "Add~" + msgs[0] + "~" + msgs[1] + "~" + msgs[2] + "~" + msgs[3] + "~" + msgs[4] + "~" + msgs[5]);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return end;
    }

    @Override
    protected void onPostExecute(String value) {
        progressDialog.dismiss();
    }
}
