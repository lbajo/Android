package es.urjc.mov.lbajo.fichas;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class SeeFile extends Activity {
    public TextView nombre, descrip, dific;
    String name, description, difficulty, photo, latitude, longitude;

    protected class oneClick implements View.OnClickListener {
        public void onClick(View v) {
            Button but = (Button) v;
            int n = but.getId();
            if (n == R.id.map){
                // intent.setData(Uri.parse("google.streetview:cbll=40.420280,"+"-3.705660&cbp=1,0,,0,1.0&mz=mapZoom"));
                // intent.setData(Uri.parse("google.streetview:cbll=40.312515,"+"-3.783250&cbp=1,0,,0,1.0&mz=mapZoom"));
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("google.streetview:cbll="+latitude+","+longitude+"&cbp=1,0,,0,1.0&mz=mapZoom"));
                startActivity(intent);
            }

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.see_file);
        Button button = (Button) findViewById(R.id.map);
        button.setOnClickListener(new oneClick());
        Intent i = getIntent();
        Bundle msg = i.getExtras();
        if (msg != null) {
            name = msg.getString("name");
            description = msg.getString("description");
            difficulty = msg.getString("difficulty");
            latitude = msg.getString("latitude");
            longitude = msg.getString("longitude");
            photo= msg.getString("photo");
          //  System.err.println(name+description+difficulty+latitude+longitude+photo);
        }
        montar();
    }

    public void montar(){
        nombre = (TextView) findViewById(R.id.name);
        descrip = (TextView) findViewById(R.id.descrip);
        dific = (TextView) findViewById(R.id.dif);
        ImageView imagen = (ImageView) findViewById(R.id.image);

        nombre.setText(name);
        descrip.setText(description);
        dific.setText("Dificultad: "+difficulty);
        imagen.setImageBitmap(Mess.decodeBase64ToImage(photo));
    }
}
