package es.urjc.mov.lbajo.fichas;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class Form extends Activity {
    static final int REQUEST_IMAGE_CAPTURE = 1;
    public EditText latitude, longitude, name, description, difficulty;
    String photo, diff;
    Context context = this;

    protected class oneClick implements View.OnClickListener {
        public void onClick(View v) {
            Button but = (Button) v;
            int n = but.getId();

            if (n == R.id.fotos) {
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                    startActivityForResult(takePictureIntent,
                            REQUEST_IMAGE_CAPTURE);
                }
            } else if (n == R.id.add) {

                Client client = new Client("10.0.2.2", 8080, context);
                client.execute(latitude.getText().toString(), longitude.getText().toString(), name.getText().toString(), description.getText().toString(), diff, photo);

                DBHelper DB = new DBHelper(getApplicationContext());
                DB.newFile(name.getText().toString(), description.getText().toString(), diff, photo, latitude.getText().toString(), longitude.getText().toString());
                Intent filter = new Intent(Form.this, Filter.class);
                startActivity(filter);
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.form);

        latitude = (EditText) findViewById(R.id.lat);
        longitude = (EditText) findViewById(R.id.lon);
        name = (EditText) findViewById(R.id.nombre);
        description = (EditText) findViewById(R.id.descrip);
       // difficulty = (EditText) findViewById(R.id.dificultad);

        Button fotos = (Button) findViewById(R.id.fotos);
        Button add = (Button) findViewById(R.id.add);

        add.setOnClickListener(new oneClick());
        fotos.setOnClickListener(new oneClick());

        Spinner diffS = (Spinner) findViewById(R.id.diffi);
        String[] valuesDiff = {"Alta", "Media", "Baja"};
        diffS.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, valuesDiff));
        diffS.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                switch (position) {
                    case 1:
                        diff= "alta";
                        break;
                    case 2:
                        diff= "media";
                        break;
                    case 3:
                       diff = "baja";
                        break;
                    default:
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            photo = Mess.encodeImageToBase64(imageBitmap, Bitmap.CompressFormat.JPEG, 100);
        /*    ImageView imagen = (ImageView) findViewById(R.id.image);
            imagen.setImageBitmap(imageBitmap);*/

        }
    }
}

