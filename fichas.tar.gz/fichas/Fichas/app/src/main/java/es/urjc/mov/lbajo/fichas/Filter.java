package es.urjc.mov.lbajo.fichas;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class Filter extends Activity {

    protected class oneClick implements View.OnClickListener {
        public void onClick(View v) {

            Button but = (Button) v;
            int n = but.getId();

            if (n == R.id.add) {
                Intent newFile = new Intent(Filter.this, Form.class);
                startActivity(newFile);
            } else {
                Intent files = new Intent(Filter.this, Files.class);
                files.putExtra("diff", "no");
                startActivity(files);
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.filter);
        Button button = (Button) findViewById(R.id.todo);
        button.setOnClickListener(new oneClick());
        Button but = (Button) findViewById(R.id.add);
        but.setOnClickListener(new oneClick());

        Spinner diffS = (Spinner) findViewById(R.id.spinner);
        String[] valuesDiff = {"Ninguna", "Alta", "Media", "Baja"};
        diffS.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, valuesDiff));
        diffS.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                //     System.err.println(id+"p"+position);
                Intent files = new Intent(Filter.this, Files.class);
                switch (position) {
                    case 1:
                       // System.err.println("ALTA" + position);

                        files.putExtra("diff", "alta");
                        startActivity(files);
                        break;
                    case 2:
                      //  System.err.println("MEDIA" + position);

                        files.putExtra("diff", "media");
                        startActivity(files);
                        break;
                    case 3:
                     //   System.err.println("BAJA" + position);

                        files.putExtra("diff", "baja");
                        startActivity(files);
                        break;
                    default:
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}
