package es.urjc.mov.lbajo.fichas;

public class Card {
    private String name;
    private String description;
    private String difficulty;
    private String photo;
    Coordinates coord;

    Card(String name, String description, String difficulty, String photo, Coordinates coord) {

        this.name = name;
        this.description = description;
        this.difficulty = difficulty;
        this.photo = photo;
        this.coord = coord;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public Coordinates getCoordinates() {
        return coord;
    }

    public void setCoordinates(Coordinates coord) {
        this.coord = coord;
    }


}
