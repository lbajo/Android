package es.urjc.mov.lbajo.fichas;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {
    private static final String NAME = "fichas.db";
    private final static int VERSION = 1;
    private Context context;

    private final static String COORDINATES = "coordinates";
    private final static String FILES = "files";

    private final static String CREATE_COORDINATES = "CREATE TABLE " + COORDINATES + " (" +
            " _idCoord INTEGER PRIMARY KEY AUTOINCREMENT, " +
            " latitude TEXT, " +
            " longitude TEXT);";

    private final static String CREATE_FILES = "CREATE TABLE " + FILES + " (" +
            " _id INTEGER PRIMARY KEY AUTOINCREMENT, " +
            " name TEXT, " +
            " description TEXT, " +
            " difficulty TEXT, " +
            " photo TEXT, " +
            " coordinates INTEGER, " +
            " FOREIGN KEY(coordinates) REFERENCES " + COORDINATES + "(_idCoord));";

    public DBHelper(Context context) {
        super(context, NAME, null, VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        //Log.v(database.class.getName(),"Creating DB.");
        database.execSQL(CREATE_COORDINATES);
        database.execSQL(CREATE_FILES);
    }

    private void doReset(SQLiteDatabase database) {
        database.execSQL("DROP TABLE IF EXISTS " + COORDINATES);
        database.execSQL("DROP TABLE IF EXISTS " + FILES);
        onCreate(database);
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int from, int to) {
        //   Log.v(DB.class.getName(),"Upgrade DB, new version: " + to +", deleting data");
        doReset(database);
    }

    private long insertCoordinates(String latitude, String longitude) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        //  values.put("_idCoord", id);
        values.put("latitude", latitude);
        values.put("longitude", longitude);
        long ins = db.insert(COORDINATES, null, values);
        if (ins == -1) {
            db.close();
            throw new RuntimeException("Can't insert coordinates in database");
        }
        db.close();
        return ins;
    }

    void newFile(String name, String description, String difficulty, String photo, String latitude, String longitude) {
        long ins = insertCoordinates(latitude, longitude);
        SQLiteDatabase db = getWritableDatabase();
        if (db != null) {

            ContentValues values = new ContentValues();
            // values.put("_id", id);
            values.put("name", name);
            values.put("description", description);
            values.put("difficulty", difficulty);
            values.put("photo", photo);
            values.put("coordinates", ins);

            if (db.insert(FILES, null, values) == -1) {
                db.close();
                throw new RuntimeException("Can't insert files in database");
            }
            db.close();
        }
    }

    void deleteFile(int id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(FILES, "_id=" + id, null);
        db.close();
    }

    ArrayList<Card> listFiles() {
        String text;
        ArrayList<Card> cards = new ArrayList<>();
        SQLiteDatabase database = this.getReadableDatabase();
        String query = "SELECT " + FILES + ".name, " +
                FILES + ".description, " +
                FILES + ".difficulty, " +
                FILES + ".photo, " +
                COORDINATES + ".latitude, " +
                COORDINATES + ".longitude " + " FROM " + FILES +
                " INNER JOIN " + COORDINATES + " ON " + FILES + ".coordinates == " + COORDINATES + "._idCoord ";
        Cursor cursor = database.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            text = "";
            int i = 0;
            do {
                text = text + " Name " + cursor.getString(cursor.getColumnIndex("name")) + " Difficulty " +
                        cursor.getString(cursor.getColumnIndex("difficulty")) +
                        " Description " + cursor.getString(cursor.getColumnIndex("description")) +
                        " Photo  " + cursor.getString(cursor.getColumnIndex("photo")) +
                        ", Latitude: " + cursor.getString(cursor.getColumnIndex("latitude")) +
                        ", Longitude: " + cursor.getString(cursor.getColumnIndex("longitude")) +
                        "\n";

                Coordinates co = new Coordinates(cursor.getString(cursor.getColumnIndex("latitude")), cursor.getString(cursor.getColumnIndex("longitude")));
                Card c = new Card(cursor.getString(cursor.getColumnIndex("name")), cursor.getString(cursor.getColumnIndex("description")), cursor.getString(cursor.getColumnIndex("difficulty")), cursor.getString(cursor.getColumnIndex("photo")), co);
                cards.add(i, c);
                i++;

            } while (cursor.moveToNext());
        }

        cursor.close();
        database.close();

        //  System.err.println(text);
        return cards;
    }

}