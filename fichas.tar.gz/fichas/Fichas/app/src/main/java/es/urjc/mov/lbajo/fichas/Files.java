package es.urjc.mov.lbajo.fichas;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;

import java.util.ArrayList;

public class Files extends Activity {
    DBHelper DB;
    String diff;
    ArrayList<Card> activities = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.files);
        Intent i = getIntent();
        this.DB = new DBHelper(getApplicationContext());
        Bundle msg = i.getExtras();
        if (msg != null) {
            diff = msg.getString("diff");
        }
        createTable();
    }

    protected class oneClick implements View.OnClickListener {
        public void onClick(View v) {
            Button but = (Button) v;
            int n = but.getId();

            String name = activities.get(n).getName();
            String description = activities.get(n).getDescription();
            String difficulty = activities.get(n).getDifficulty();
            String photo = activities.get(n).getPhoto();
            String latitude = activities.get(n).getCoordinates().getLatitude();
            String longitude = activities.get(n).getCoordinates().getLongitude();
          //  System.err.println("lat" + latitude + "lon" + longitude);

            Intent seeFile = new Intent(Files.this, SeeFile.class);
            seeFile.putExtra("name", name);
            seeFile.putExtra("description", description);
            seeFile.putExtra("difficulty", difficulty);
            seeFile.putExtra("photo", photo);
            seeFile.putExtra("latitude", latitude);
            seeFile.putExtra("longitude", longitude);

            startActivity(seeFile);

        }
    }

    protected void createTable() {
        setContentView(R.layout.files);
        TableLayout table = (TableLayout) findViewById(R.id.table);
        activities = DB.listFiles();
        int si = activities.size();
        for (int i = 0; i < si; i++) {
            String difficulty = activities.get(i).getDifficulty();
            if (diff.equals("no") || diff.equals(difficulty)) {
                TableRow tableRow = new TableRow(this);
                tableRow.setLayoutParams(new TableLayout.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.MATCH_PARENT, 1));
                Button cell = new Button(this);
                cell.setId(i);
                String name = activities.get(i).getName();
                cell.setText(name);
                cell.setGravity(Gravity.CENTER);
               // cell.setTextColor(getResources().ContextCompat.getColor(context, R.color.your_color););
                cell.setOnClickListener(new oneClick());
                tableRow.addView(cell);
                table.addView(tableRow);
            }
        }
    }
}
