package es.urjc.mov.lbajo.fichas;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class MainActivity extends Activity {

    public EditText user, password, lat, lon;
    private TextView conex;
    Context context = this;
    Client client;
    String lati, longi;

    protected class oneClick implements View.OnClickListener {
        public void onClick(View v) {
            if (ActivityCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions((Activity) context, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION,}, 1000);
            } else {
                location();
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = (Button) findViewById(R.id.login);
        Button buttonLoc = (Button) findViewById(R.id.add);
        user = (EditText) findViewById(R.id.user);
        password = (EditText) findViewById(R.id.password);
        lat = (EditText) findViewById(R.id.lat);
        lon = (EditText) findViewById(R.id.lon);
        password.setTypeface(Typeface.DEFAULT);
        password.setTransformationMethod(new PasswordTransformationMethod());
        conex = (TextView) findViewById(R.id.txt_conex);
        button.setOnClickListener(buttonConnectOnClickListener);
        buttonLoc.setOnClickListener(new oneClick());
    }

    OnClickListener buttonConnectOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View arg0) {
            client = new Client("10.0.2.2", 8080, context);
            client.execute("first", user.getText().toString(), password.getText().toString(), lat.getText().toString(), lon.getText().toString());

            try {
                if (client.get().equals("OK")) {
                    conex.setText("Conexión exitosa");
                    newDB();
                    Intent filter = new Intent(MainActivity.this, Filter.class);
                    startActivity(filter);
                } else {
                    conex.setText("Conexión errónea");
                }

            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
        }
    };

    void newDB() {
        boolean exists = false;
        DBHelper DB = new DBHelper(getApplicationContext());
        ArrayList<Card> activities;
        activities = DB.listFiles();
        //System.err.print(DB.listFiles());

        for (int i = 0; i < client.info.size(); i++) {
            String[] parts = client.info.get(i).split("~");
            for (int j = 0; j < activities.size(); j++) {
                if (activities.get(j).getName().equals(parts[2]))
                    exists = true;

            }
            if (!exists)
                DB.newFile(parts[2], parts[3], parts[4], parts[5], parts[0], parts[1]);
            exists = false;
        }
    }

    private void location() {
        LocationManager mlocManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        MyLocation myLoc = new MyLocation();

        final boolean gpsEnabled = mlocManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        if (!gpsEnabled) {
            Intent settingsIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            startActivity(settingsIntent);
        }

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        mlocManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, (LocationListener) myLoc);
        mlocManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, (LocationListener) myLoc);

    }

    public class MyLocation implements LocationListener {
        @Override
        public void onLocationChanged(Location loc) {

            lati = Double.toString(loc.getLatitude());
            longi = Double.toString(loc.getLongitude());

            //  System.err.println("Lat  " + lati + " Long  " + longi);
            lat.setText(lati);
            lon.setText(longi);
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
            switch (status) {
                case LocationProvider.AVAILABLE:
                    Log.d("debug", "LocationProvider.AVAILABLE");
                    break;
                case LocationProvider.OUT_OF_SERVICE:
                    Log.d("debug", "LocationProvider.OUT_OF_SERVICE");
                    break;
                case LocationProvider.TEMPORARILY_UNAVAILABLE:
                    Log.d("debug", "LocationProvider.TEMPORARILY_UNAVAILABLE");
                    break;
            }
        }

        @Override
        public void onProviderEnabled(String provider) {

        }

        @Override
        public void onProviderDisabled(String provider) {

        }
    }
}

