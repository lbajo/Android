package es.urjc.mov.lbajo.fichas;


import android.support.test.rule.ActivityTestRule;
import android.widget.TextView;

import org.junit.Rule;
import org.junit.Test;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.closeSoftKeyboard;
import static android.support.test.espresso.action.ViewActions.typeText;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static junit.framework.Assert.assertEquals;

public class ConexionTest {

    @Rule
    public ActivityTestRule<MainActivity> mActivityRule = new ActivityTestRule<>(MainActivity.class);

    @Test
    public void conexionOK() {
        TextView conex = (TextView) mActivityRule.getActivity().findViewById(R.id.txt_conex);

        onView(withId(R.id.user)).perform(typeText("Lorena"), closeSoftKeyboard());
        onView(withId(R.id.password)).perform(typeText("android"), closeSoftKeyboard());
        onView(withId(R.id.lat)).perform(typeText("40.2"), closeSoftKeyboard());
        onView(withId(R.id.lon)).perform(typeText("-3.79"), closeSoftKeyboard());
        onView(withId(R.id.login)).perform(click());

        assertEquals(conex.getText(),"Conexión exitosa");

    }

    @Test
    public void conexionKO() {
        TextView conex = (TextView) mActivityRule.getActivity().findViewById(R.id.txt_conex);

        onView(withId(R.id.user)).perform(typeText("NoSoyLorena"), closeSoftKeyboard());
        onView(withId(R.id.password)).perform(typeText("blabla"), closeSoftKeyboard());
        onView(withId(R.id.lat)).perform(typeText("40.2"), closeSoftKeyboard());
        onView(withId(R.id.lon)).perform(typeText("-3.79"), closeSoftKeyboard());
        onView(withId(R.id.login)).perform(click());

        assertEquals(conex.getText(),"Conexión errónea");

    }

}
