package es.urjc.mov.lbajo.fichas;

import android.content.Context;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;

import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class DBTest {
    @Test
    public void insertDB() throws Exception {
        boolean OK=false;
        Context appContext = InstrumentationRegistry.getTargetContext();
        DBHelper DB = new DBHelper(appContext);
        DB.newFile("Bosque Sur", "Vamos por caminos y sendas hasta que nos adentramos en bosque Sur", "baja", "", "40.30", "-3.79");
        //System.err.println(DB.listFiles().get(0).getName());
        for (int i = 0; i < DB.listFiles().size(); i++) {
            if (DB.listFiles().get(i).getName().equals("Bosque Sur")) {
               OK=true;
            }
        }
        assertTrue(OK);
    }
}

