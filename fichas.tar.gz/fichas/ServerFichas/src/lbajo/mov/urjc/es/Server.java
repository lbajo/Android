package lbajo.mov.urjc.es;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class Server {

	static int port = 8080;
	static boolean end = false;
	static String user;
	private static final int VERSION =1;
	private static int cliVersion=0;
	private static Boolean isFirst = true;
	static double radio =20;

	static JSONParser parser = new JSONParser();
	
	public static double deg2rad(double deg) {
		  return deg * (Math.PI/180);
	}
	
	public static double getDistance(double lat1,double lon1,double lat2, double lon2) {
		int R = 6371; 
		
		double dLat = deg2rad(lat2-lat1); 
		double dLon = deg2rad(lon2-lon1); 
		double a = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
		    Math.sin(dLon/2) * Math.sin(dLon/2); 
		double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
		double d = R * c;
		
		return d;
	}
	
	public static void readFiles(DataOutputStream out, double milati, double milongi){
		
		String direct = "/home/alumnos/lbajo/PFAndroid/Fichas";
		File f = new File(direct);
		
		File[] fichs = f.listFiles();
		for (int i=0;i<fichs.length;i++){
		 // System.out.println(fichs[i].getName());
		  if(!"infoPF.json".equals(fichs[i].getName())){
			  JSONParser parser = new JSONParser();
				try{
					Object obj = parser.parse(new FileReader("/home/alumnos/lbajo/PFAndroid/Fichas/"+fichs[i].getName()));
					 
					JSONObject jsonObject = (JSONObject) obj;
			 
					String lat = (String) jsonObject.get("latitud");
					String longi = (String) jsonObject.get("longitud");
					
					double lati = Double.parseDouble(lat);
					double longit = Double.parseDouble(longi);
					
					
					String nombre = (String) jsonObject.get("nombre");
					String desc = (String) jsonObject.get("descripción");
					String fotos = (String) jsonObject.get("fotos");
					String dif = (String) jsonObject.get("dificultad");
					
					String ft = Mess.getImage(fotos);
					String msg = lat + '~' + longi + '~'+ nombre + '~' + desc + '~' + dif+'~'+ft;
					
					if(getDistance(milati,milongi,lati,longit)<=radio){
						System.err.println(msg);
						Mess.writeMess(out, msg);
					}
					
				} catch (Exception e) {
					e.printStackTrace();
				}
		  }else{
			  try {
					JSONArray fich = (JSONArray) parser.parse(new FileReader("/home/alumnos/lbajo/PFAndroid/Fichas/infoPF.json"));
					//Esto hay que cambiarlo dependiendo de dónde se encuentre elfichero

					for (Object obj : fich) {
						JSONObject jsonObject2 = (JSONObject) obj;
						
						String lat = (String) jsonObject2.get("latitud");
						String longi = (String) jsonObject2.get("longitud");
						
						double lati = Double.parseDouble(lat);
						double longit = Double.parseDouble(longi);
						
						String nombre = (String) jsonObject2.get("nombre");
						String desc = (String) jsonObject2.get("descripción");
						String fotos = (String) jsonObject2.get("fotos");
						String dif = (String) jsonObject2.get("dificultad");
						
						String ft = Mess.getImage(fotos);
						String msg = lat + '~' + longi + '~'+ nombre + '~' + desc + '~' + dif+'~'+ft;
					//	String msg = lat + '/' + longi + '/'+ nombre + '/' + desc + '/' + dif+'/'+ft;
							
								if(getDistance(milati,milongi,lati,longit)<=radio){
									System.err.println(msg);
									Mess.writeMess(out, msg);
								}
							
					}

				} catch (Exception e) {
					e.printStackTrace();
				}
			  
		  }
		}
		
	}
	
	public static void sendNum(DataOutputStream out, double milati, double milongi){
		int num=0;
		
		String direct = "/home/alumnos/lbajo/PFAndroid/Fichas";
		File f = new File(direct);
		
		File[] fichs = f.listFiles();
		
		for (int i=0;i<fichs.length;i++){
			  //System.out.println(fichs[i].getName());
			  if(!"infoPF.json".equals(fichs[i].getName())){
				  JSONParser parser = new JSONParser();
					try{
						Object obj = parser.parse(new FileReader("/home/alumnos/lbajo/PFAndroid/Fichas/"+fichs[i].getName()));
						 
						JSONObject jsonObject = (JSONObject) obj;
						
						
						String latit = (String) jsonObject.get("latitud");
						String longitu = (String) jsonObject.get("longitud");
						
						double lati = Double.parseDouble(latit);
						double longit = Double.parseDouble(longitu);
				 
						if(getDistance(milati,milongi,lati,longit)<=radio){
							num++;
						}
						
					} catch (Exception e) {
						e.printStackTrace();
					}
			  }else{
				  try {
						JSONArray fich = (JSONArray) parser.parse(new FileReader("/home/alumnos/lbajo/PFAndroid/Fichas/infoPF.json"));
						//Esto hay que cambiarlo dependiendo de dónde se encuentre el fichero
						
						for (Object objt : fich) {
							JSONObject jsonObject = (JSONObject) objt;
							
							String latit = (String) jsonObject.get("latitud");
							String longitu = (String) jsonObject.get("longitud");
							
							double lati = Double.parseDouble(latit);
							double longit = Double.parseDouble(longitu);
				 
							if(getDistance(milati,milongi,lati,longit)<=radio){
								num++;
							}	 
						}
						

					} catch (Exception e) {
						e.printStackTrace();
					}
				  
			  }
			}
		
		String msg = "OK" + '/' + String.valueOf(num);
		
		try {
			Mess.writeMess(out, msg);
		} catch (Exception e) {
			e.printStackTrace();
		}
		readFiles(out,milati,milongi);
		
		
	}
	
	@SuppressWarnings("unchecked")
	public static void addFiles(String latitud, String longitud, String nombre, String descrip, String dificultad, String fotos){
		JSONObject obj = new JSONObject();
		String rutafoto="/home/alumnos/lbajo/PFAndroid/Fotos/";
		
		obj.put("latitud",latitud);
		obj.put("longitud", longitud);
		obj.put("nombre", nombre);
		obj.put("descripción", descrip);
		obj.put("fotos", rutafoto+nombre+".jpg");
		obj.put("dificultad", dificultad);
		
		
		try {

			FileWriter file = new FileWriter("/home/alumnos/lbajo/PFAndroid/Fichas/"+nombre+".json");
			file.write(obj.toJSONString());
			file.flush();
			file.close();
			
			Mess.createImage(fotos, nombre);

		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public static void processRequest(DataInputStream in, DataOutputStream out) throws Exception{
		String msg = Mess.readMess(in);
		
		String[] parts = msg.split("~");
		if(parts[0].equals("Add"))
			//System.err.println(parts[1]+parts[2]+parts[3]+parts[4]+parts[5]+parts[6]);
			addFiles(parts[1],parts[2],parts[3],parts[4],parts[5],parts[6]);
	}


	public static void writeMess(DataOutputStream out, String msg) throws Exception {
		String[] parts = msg.split("/");
		if (parts[0].equals("Lorena")&&parts[1].equals("android") ||parts[0].equals("Nuria")&&parts[1].equals("android")) {
			System.err.println("Usuario: "+parts[0]);
			user = parts[0];
		//	System.err.println("lat"+parts[2]);
		//	System.err.println("lon"+parts[3]);
			
			double lat = Double.parseDouble(parts[2]);
			double lon = Double.parseDouble(parts[3]);
			setCliVersion(Integer.parseInt(parts[4]));
			sendNum(out, lat, lon);
		} else {
			Mess.writeMess(out, "KO");
			System.err.println("Error de autenticación");
			end = true;
		}
	}

	public static void readMsg(DataInputStream in, DataOutputStream out) throws Exception {
		if (!end) {
			String msg = Mess.readMess(in);
			writeMess(out, msg);
		}
	}

	public static void main(String[] args) {
		ServerSocket servsocket = null;
		try {
			servsocket = new ServerSocket(port);
			System.out.println("Esperando clientes...");
	//		System.out.println("DIST"+getDistance(11,7,8,3));
			while (true) {
				Socket socket = servsocket.accept();
				System.out.println("¡Cliente conectado!");
				DataInputStream in = new DataInputStream(socket.getInputStream());
				DataOutputStream out = new DataOutputStream(socket.getOutputStream());
				if(isFirst){
					readMsg(in, out);
					isFirst = false;
					continue;
				}
				processRequest(in,out);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (servsocket != null) {
					servsocket.close();
				}
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		System.err.println("FIN");
	}

	public static int getCliVersion() {
		return cliVersion;
	}

	public static void setCliVersion(int cliVersion) {
		Server.cliVersion = cliVersion;
	}

	public static int getVersion() {
		return VERSION;
	}
}
