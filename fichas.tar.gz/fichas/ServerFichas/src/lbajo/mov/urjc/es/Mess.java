package lbajo.mov.urjc.es;


import java.io.DataInputStream;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Mess {

    protected static void writeMess(DataOutputStream out, String msg) throws Exception {
        byte[] buff = msg.getBytes("UTF-8");
        out.writeInt(buff.length);
        out.write(buff, 0, buff.length);
    }

    protected static String readMess(DataInputStream in) throws Exception {
        int len = in.readInt();
        byte bufin[] = new byte[len];
        in.readFully(bufin);
        return new String(bufin, "UTF-8");
    }

    protected static String getImage(String route) throws Exception{
    	File imageFile= new File(route);
    	//System.err.println(route);

        String image=null;
        BufferedImage buffImage = ImageIO.read(imageFile);

        if (buffImage != null) {
       	 java.io.ByteArrayOutputStream os = new java.io.ByteArrayOutputStream();
       	 ImageIO.write(buffImage, "jpg", os);
       	 byte[] data = os.toByteArray();
       	 image = ToBase64.encode(data);
        }
        
        return image;
    }
    
    protected static void createImage(String imageString, String name) throws IOException{

    	byte[] imageByte = javax.xml.bind.DatatypeConverter.parseBase64Binary(imageString);
    	ByteArrayInputStream bis = new ByteArrayInputStream(imageByte);
    	BufferedImage image = ImageIO.read(bis);
    	bis.close();

    	File outputfile = new File("/home/alumnos/lbajo/PFAndroid/Fotos/"+name+".jpg");
    	ImageIO.write(image, "jpg", outputfile);//png
    	
    }
}